<?php
/**
 * Name: Features 2
 * Category: Features
 * Source: https://wp.nkdev.info/skylith/demo-minimal-classic-agency/about-us/
 *
 * @package skylith/templates
 */

?>
<!-- wp:nk/awb {"type":"image","align":"full","image":352,"imageTag":"\u003cdiv class=\u0022jarallax-img\u0022 style=\u0022background-image: url(\u0026quot;\u0026quot;);\u0022\u003e\u003c/div\u003e","imageSizes":{"full":{"url":"https://wp.nkdev.info/skylith/demo-minimal-classic-agency/wp-content/uploads/sites/3/2018/11/bg-pattern.svg","width":"67","height":"41","orientation":"landscape"}},"imageBackgroundSize":"pattern","color":"rgba(0, 0, 0, 0.2)","parallax":"scroll","parallaxSpeed":0.8,"className":"ghostkit-custom-2aUMnK","ghostkitStyles":{".ghostkit-custom-2aUMnK":{"paddingTop":"95","paddingBottom":"55","paddingLeft":"0","paddingRight":"0"}},"ghostkitClassname":"ghostkit-custom-2aUMnK","ghostkitId":"2aUMnK","ghostkitSpacings":{"paddingTop":"95","paddingBottom":"55","paddingLeft":"0","paddingRight":"0"},"ghostkitIndents":{}} -->
<div class="wp-block-nk-awb nk-awb  alignfull ghostkit-custom-2aUMnK"><div class="nk-awb-wrap" data-awb-type="image" data-awb-image-background-size="pattern" data-awb-image-background-position="50% 50%" data-awb-parallax="scroll" data-awb-parallax-speed="0.8" data-awb-parallax-mobile="false"><div class="nk-awb-overlay" style="background-color: rgba(0, 0, 0, 0.2);"></div><div class="nk-awb-inner"><div class="jarallax-img" style="background-image: url('');"></div></div></div><!-- wp:ghostkit/grid {"columns":4,"ghostkitSpacings":{},"ghostkitIndents":{}} -->
<div class="ghostkit-grid ghostkit-grid-gap-md"><div class="ghostkit-grid-inner"><!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-diamond","iconPosition":"top","iconSize":50,"iconColor":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","className":"ghostkit-custom-XX0pr","ghostkitStyles":{".ghostkit-custom-XX0pr":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#d086d3","\u0026:hover":{"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"none"},"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-XX0pr","ghostkitId":"XX0pr","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px"} -->
<div class="ghostkit-icon-box ghostkit-pro-text-gradient ghostkit-custom-XX0pr" data-ghostkit-sr="fade-up;distance:10px"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-top"><span class="pe-7s-diamond"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"align":"center","textColor":"skylith-white","customFontSize":13.65,"className":"has-custom-size ghostkit-custom-Z1UMjT4","ghostkitStyles":{".ghostkit-custom-Z1UMjT4":{"marginBottom":"8"}},"ghostkitClassname":"ghostkit-custom-Z1UMjT4","ghostkitId":"Z1UMjT4","ghostkitSpacings":{"marginBottom":"8"}} -->
<p style="font-size:13.65px" class="has-text-color has-text-align-center has-skylith-white-color has-custom-size ghostkit-custom-Z1UMjT4">CREATIVE IDEAS</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","customTextColor":"#cccccc","customFontSize":15,"className":"has-custom-size ghostkit-custom-aHNHR","ghostkitStyles":{".ghostkit-custom-aHNHR":{"marginBottom":"0"}},"ghostkitClassname":"ghostkit-custom-aHNHR","ghostkitId":"aHNHR","ghostkitSpacings":{"marginBottom":"0"}} -->
<p style="color:#cccccc;font-size:15px" class="has-text-color has-text-align-center has-custom-size ghostkit-custom-aHNHR">Donec finibus ulicies vulputate mollis massa laoreet</p>
<!-- /wp:paragraph --></div></div>
            <div class="ghostkit-pro-gradient-mask" style="position: absolute; left: -9999px;" data-gradient-style="linear-gradient(90deg, #d086d3 0%, #a074dc 100%)" data-gradient-id="ghostkit-pro-svg-gradient-icon-box-XX0pr" data-gradient-selector=".ghostkit-custom-XX0pr .ghostkit-icon-box-icon"></div>

<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-arc","iconPosition":"top","iconSize":50,"iconColor":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","className":"ghostkit-custom-Z1jkC0I","ghostkitStyles":{".ghostkit-custom-Z1jkC0I":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#d086d3","\u0026:hover":{"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"none"},"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-Z1jkC0I","ghostkitId":"Z1jkC0I","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:150"} -->
<div class="ghostkit-icon-box ghostkit-pro-text-gradient ghostkit-custom-Z1jkC0I" data-ghostkit-sr="fade-up;distance:10px;delay:150"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-top"><span class="pe-7s-arc"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"align":"center","textColor":"skylith-white","customFontSize":13.65,"className":"has-custom-size ghostkit-custom-QU6Gb","ghostkitStyles":{".ghostkit-custom-QU6Gb":{"marginBottom":"8"}},"ghostkitClassname":"ghostkit-custom-QU6Gb","ghostkitId":"QU6Gb","ghostkitSpacings":{"marginBottom":"8"}} -->
<p style="font-size:13.65px" class="has-text-color has-text-align-center has-skylith-white-color has-custom-size ghostkit-custom-QU6Gb">REALLY CLEAN CODE</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","customTextColor":"#cccccc","customFontSize":15,"className":"has-custom-size ghostkit-custom-ZUlXoR","ghostkitStyles":{".ghostkit-custom-ZUlXoR":{"marginBottom":"0"}},"ghostkitClassname":"ghostkit-custom-ZUlXoR","ghostkitId":"ZUlXoR","ghostkitSpacings":{"marginBottom":"0"}} -->
<p style="color:#cccccc;font-size:15px" class="has-text-color has-text-align-center has-custom-size ghostkit-custom-ZUlXoR">Donec finibus ulicies vulputate mollis massa laoreet</p>
<!-- /wp:paragraph --></div></div>
            <div class="ghostkit-pro-gradient-mask" style="position: absolute; left: -9999px;" data-gradient-style="linear-gradient(90deg, #d086d3 0%, #a074dc 100%)" data-gradient-id="ghostkit-pro-svg-gradient-icon-box-Z1jkC0I" data-gradient-selector=".ghostkit-custom-Z1jkC0I .ghostkit-icon-box-icon"></div>

<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-headphones","iconPosition":"top","iconSize":50,"iconColor":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","className":"ghostkit-custom-STpiK","ghostkitStyles":{".ghostkit-custom-STpiK":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#d086d3","\u0026:hover":{"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"none"},"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-STpiK","ghostkitId":"STpiK","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:300"} -->
<div class="ghostkit-icon-box ghostkit-pro-text-gradient ghostkit-custom-STpiK" data-ghostkit-sr="fade-up;distance:10px;delay:300"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-top"><span class="pe-7s-headphones"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"align":"center","textColor":"skylith-white","customFontSize":13.65,"className":"has-custom-size ghostkit-custom-ZWPgad","ghostkitStyles":{".ghostkit-custom-ZWPgad":{"marginBottom":"8"}},"ghostkitClassname":"ghostkit-custom-ZWPgad","ghostkitId":"ZWPgad","ghostkitSpacings":{"marginBottom":"8"}} -->
<p style="font-size:13.65px" class="has-text-color has-text-align-center has-skylith-white-color has-custom-size ghostkit-custom-ZWPgad">SUPPORT 24/7</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","customTextColor":"#cccccc","customFontSize":15,"className":"has-custom-size ghostkit-custom-Z2dkUD9","ghostkitStyles":{".ghostkit-custom-Z2dkUD9":{"marginBottom":"0"}},"ghostkitClassname":"ghostkit-custom-Z2dkUD9","ghostkitId":"Z2dkUD9","ghostkitSpacings":{"marginBottom":"0"}} -->
<p style="color:#cccccc;font-size:15px" class="has-text-color has-text-align-center has-custom-size ghostkit-custom-Z2dkUD9">Donec finibus ulicies vulputate mollis massa laoreet</p>
<!-- /wp:paragraph --></div></div>
            <div class="ghostkit-pro-gradient-mask" style="position: absolute; left: -9999px;" data-gradient-style="linear-gradient(90deg, #d086d3 0%, #a074dc 100%)" data-gradient-id="ghostkit-pro-svg-gradient-icon-box-STpiK" data-gradient-selector=".ghostkit-custom-STpiK .ghostkit-icon-box-icon"></div>

<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-medal","iconPosition":"top","iconSize":50,"iconColor":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","className":"ghostkit-custom-Z24sRzN","ghostkitStyles":{".ghostkit-custom-Z24sRzN":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#d086d3","\u0026:hover":{"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"none"},"\u002d\u002dgkt-pro-icon-box\u002d\u002dicon__image":"linear-gradient(90deg, #d086d3 0%, #a074dc 100%)","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-Z24sRzN","ghostkitId":"Z24sRzN","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:450"} -->
<div class="ghostkit-icon-box ghostkit-pro-text-gradient ghostkit-custom-Z24sRzN" data-ghostkit-sr="fade-up;distance:10px;delay:450"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-top"><span class="pe-7s-medal"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"align":"center","textColor":"skylith-white","customFontSize":13.65,"className":"has-custom-size ghostkit-custom-Z2qylvG","ghostkitStyles":{".ghostkit-custom-Z2qylvG":{"marginBottom":"8"}},"ghostkitClassname":"ghostkit-custom-Z2qylvG","ghostkitId":"Z2qylvG","ghostkitSpacings":{"marginBottom":"8"}} -->
<p style="font-size:13.65px" class="has-text-color has-text-align-center has-skylith-white-color has-custom-size ghostkit-custom-Z2qylvG">TALENTED TEAM</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","customTextColor":"#cccccc","customFontSize":15,"className":"has-custom-size ghostkit-custom-K1Xz7","ghostkitStyles":{".ghostkit-custom-K1Xz7":{"marginBottom":"0"}},"ghostkitClassname":"ghostkit-custom-K1Xz7","ghostkitId":"K1Xz7","ghostkitSpacings":{"marginBottom":"0"}} -->
<p style="color:#cccccc;font-size:15px" class="has-text-color has-text-align-center has-custom-size ghostkit-custom-K1Xz7">Donec finibus ulicies vulputate mollis massa laoreet</p>
<!-- /wp:paragraph --></div></div>
            <div class="ghostkit-pro-gradient-mask" style="position: absolute; left: -9999px;" data-gradient-style="linear-gradient(90deg, #d086d3 0%, #a074dc 100%)" data-gradient-id="ghostkit-pro-svg-gradient-icon-box-Z24sRzN" data-gradient-selector=".ghostkit-custom-Z24sRzN .ghostkit-icon-box-icon"></div>

<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column --></div></div>
<!-- /wp:ghostkit/grid --></div>
<!-- /wp:nk/awb -->
