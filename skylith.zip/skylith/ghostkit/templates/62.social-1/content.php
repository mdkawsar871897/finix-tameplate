<?php
/**
 * Name: Twitter 1
 * Category: Social
 * Source: https://wp.nkdev.info/skylith/demo-creative-designer-portfolio/
 *
 * @package skylith/templates
 */

?>
<!-- wp:nk/awb {"align":"full","color":"#f2f2f2","className":"ghostkit-custom-1vO7cJ","ghostkitStyles":{".ghostkit-custom-1vO7cJ":{"paddingTop":"100","paddingBottom":"75","paddingLeft":"0","paddingRight":"0"}},"ghostkitClassname":"ghostkit-custom-1vO7cJ","ghostkitId":"1vO7cJ","ghostkitSpacings":{"paddingTop":"100","paddingBottom":"75","paddingLeft":"0","paddingRight":"0"}} -->
<div class="wp-block-nk-awb nk-awb  alignfull ghostkit-custom-1vO7cJ"><div class="nk-awb-wrap" data-awb-type="color"><div class="nk-awb-overlay" style="background-color: #f2f2f2;"></div></div><!-- wp:ghostkit/twitter {"consumerKey":"hMJ4xIvKvoRwjry4a6TmmwIr3","consumerSecret":"fDnpvj7xbgw2vuKEr5gC430reM1WTDAmyol6SLwjbr6cPfiwLZ","accessToken":"2848523763-EoquJ3UfxZkmOEPPpi8CrFYzTxDYEGPwdyI8zWk","accessTokenSecret":"aTvW8OK0qNHxZdrz1SYLBAk09lErKZtXyJCOBaCJV1mqv","count":4,"showFeedAvatar":false,"feedAvatarSize":30,"feedTextConvertLinks":"links","showProfile":false,"className":"ghostkit-twitter-variant-skylith-alt-1"} /--></div>
<!-- /wp:nk/awb -->
