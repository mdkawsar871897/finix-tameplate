<?php
/**
 * Name: Counters 1
 * Category: Counters
 * Source: https://wp.nkdev.info/skylith/demo-creative-agency/about-us/
 *
 * @package skylith/templates
 */

?>
<!-- wp:nk/awb {"align":"full","color":"#1a1a1a","parallax":"scroll","parallaxSpeed":0.8,"className":"ghostkit-custom-1cqcCb","ghostkitStyles":{".ghostkit-custom-1cqcCb":{"paddingTop":"95","paddingBottom":"55","paddingLeft":"0","paddingRight":"0"}},"ghostkitClassname":"ghostkit-custom-1cqcCb","ghostkitId":"1cqcCb","ghostkitSpacings":{"paddingTop":"95","paddingBottom":"55","paddingLeft":"0","paddingRight":"0"},"ghostkitIndents":{}} -->
<div class="wp-block-nk-awb nk-awb  alignfull ghostkit-custom-1cqcCb"><div class="nk-awb-wrap" data-awb-type="color" data-awb-parallax="scroll" data-awb-parallax-speed="0.8" data-awb-parallax-mobile="false"><div class="nk-awb-overlay" style="background-color: #1a1a1a;"></div></div><!-- wp:ghostkit/grid {"columns":4,"ghostkitSpacings":{},"ghostkitIndents":{}} -->
<div class="ghostkit-grid ghostkit-grid-gap-md"><div class="ghostkit-grid-inner"><!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-portfolio","iconSize":50,"iconColor":"#ea2f5c","className":"ghostkit-custom-Z1vtKFJ","ghostkitStyles":{".ghostkit-custom-Z1vtKFJ":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#ea2f5c","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-Z1vtKFJ","ghostkitId":"Z1vtKFJ","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px"} -->
<div class="ghostkit-icon-box ghostkit-custom-Z1vtKFJ" data-ghostkit-sr="fade-up;distance:10px"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-portfolio"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":18.75,"className":"has-custom-size ghostkit-custom-Zc4P3R","ghostkitStyles":{".ghostkit-custom-Zc4P3R":{"marginBottom":"0","marginTop":"-3"}},"ghostkitClassname":"ghostkit-custom-Zc4P3R","ghostkitId":"Zc4P3R","ghostkitSpacings":{"marginBottom":"0","marginTop":"-3"},"ghostkitIndents":{}} -->
<p style="color:#ffffff;font-size:18.75px" class="has-text-color has-custom-size ghostkit-custom-Zc4P3R"><strong>548</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":13.65,"className":"has-custom-size"} -->
<p style="color:#ffffff;font-size:13.65px" class="has-text-color has-custom-size"><strong>PROJECTS COMPLETED</strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-clock","iconSize":50,"iconColor":"#ea2f5c","className":"ghostkit-custom-ZCTecX","ghostkitStyles":{".ghostkit-custom-ZCTecX":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#ea2f5c","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-ZCTecX","ghostkitId":"ZCTecX","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:150"} -->
<div class="ghostkit-icon-box ghostkit-custom-ZCTecX" data-ghostkit-sr="fade-up;distance:10px;delay:150"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-clock"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":18.75,"className":"has-custom-size ghostkit-custom-1KEcNS","ghostkitStyles":{".ghostkit-custom-1KEcNS":{"marginBottom":"0","marginTop":"-3"}},"ghostkitClassname":"ghostkit-custom-1KEcNS","ghostkitId":"1KEcNS","ghostkitSpacings":{"marginBottom":"0","marginTop":"-3"},"ghostkitIndents":{}} -->
<p style="color:#ffffff;font-size:18.75px" class="has-text-color has-custom-size ghostkit-custom-1KEcNS"><strong>1465</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":13.65,"className":"has-custom-size"} -->
<p style="color:#ffffff;font-size:13.65px" class="has-text-color has-custom-size"><strong>WORKING HOURS</strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-star","iconSize":50,"iconColor":"#ea2f5c","className":"ghostkit-custom-Z1aOM5U","ghostkitStyles":{".ghostkit-custom-Z1aOM5U":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#ea2f5c","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-Z1aOM5U","ghostkitId":"Z1aOM5U","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:300"} -->
<div class="ghostkit-icon-box ghostkit-custom-Z1aOM5U" data-ghostkit-sr="fade-up;distance:10px;delay:300"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-star"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":18.75,"className":"has-custom-size ghostkit-custom-1Y3sOw","ghostkitStyles":{".ghostkit-custom-1Y3sOw":{"marginBottom":"0","marginTop":"-3"}},"ghostkitClassname":"ghostkit-custom-1Y3sOw","ghostkitId":"1Y3sOw","ghostkitSpacings":{"marginBottom":"0","marginTop":"-3"},"ghostkitIndents":{}} -->
<p style="color:#ffffff;font-size:18.75px" class="has-text-color has-custom-size ghostkit-custom-1Y3sOw"><strong>612</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":13.65,"className":"has-custom-size"} -->
<p style="color:#ffffff;font-size:13.65px" class="has-text-color has-custom-size"><strong>POSITIVE FEEDBACKS</strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"sm_size":"12","md_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-sm-12 ghostkit-col-md-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-like","iconSize":50,"iconColor":"#ea2f5c","className":"ghostkit-custom-ZDihOI","ghostkitStyles":{".ghostkit-custom-ZDihOI":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"50px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#ea2f5c","marginBottom":"40"}},"ghostkitClassname":"ghostkit-custom-ZDihOI","ghostkitId":"ZDihOI","ghostkitSpacings":{"marginBottom":"40"},"ghostkitSR":"fade-up;distance:10px;delay:450"} -->
<div class="ghostkit-icon-box ghostkit-custom-ZDihOI" data-ghostkit-sr="fade-up;distance:10px;delay:450"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-like"></span></div><div class="ghostkit-icon-box-content"><!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":18.75,"className":"has-custom-size ghostkit-custom-qd1uC","ghostkitStyles":{".ghostkit-custom-qd1uC":{"marginBottom":"0","marginTop":"-3"}},"ghostkitClassname":"ghostkit-custom-qd1uC","ghostkitId":"qd1uC","ghostkitSpacings":{"marginBottom":"0","marginTop":"-3"},"ghostkitIndents":{}} -->
<p style="color:#ffffff;font-size:18.75px" class="has-text-color has-custom-size ghostkit-custom-qd1uC"><strong>735</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"customTextColor":"#ffffff","customFontSize":13.65,"className":"has-custom-size"} -->
<p style="color:#ffffff;font-size:13.65px" class="has-text-color has-custom-size"><strong>HAPPY CLIENTS</strong></p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column --></div></div>
<!-- /wp:ghostkit/grid --></div>
<!-- /wp:nk/awb -->
