<?php
/**
 * Name: Counters 3
 * Category: Counters
 * Source: https://wp.nkdev.info/skylith/demo-creative-business-one-page/
 *
 * @package skylith/templates
 */

$alt = '';

?>
<!-- wp:nk/awb {"type":"image","align":"full","image":37,"imageTag":"\u003cimg src=\u0022http://skylith.local/wp-content/uploads/2018/09/demo-minimal-split-single-4-3.png\u0022 class=\u0022wp-image-37 jarallax-img\u0022 width=\u00221280\u0022 height=\u00221610\u0022 /\u003e","imageSizes":{"thumbnail":{"height":150,"width":150,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-150x150.jpg","orientation":"landscape"},"medium":{"height":172,"width":300,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-300x172.jpg","orientation":"landscape"},"large":{"height":587,"width":1024,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1024x587.jpg","orientation":"landscape"},"vp_sm":{"height":287,"width":500,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-500x287.jpg","orientation":"landscape"},"vp_md":{"height":459,"width":800,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-800x459.jpg","orientation":"landscape"},"vp_lg":{"height":654,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1280x734.jpg","orientation":"landscape"},"vp_xl":{"height":654,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1920x1101.jpg","orientation":"landscape"},"skylith_48x48_crop":{"height":48,"width":48,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-48x48.jpg","orientation":"landscape"},"skylith_48x48":{"height":28,"width":48,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-48x28.jpg","orientation":"landscape"},"skylith_128x128_crop":{"height":128,"width":128,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-128x128.jpg","orientation":"landscape"},"skylith_128x128":{"height":73,"width":128,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-128x73.jpg","orientation":"landscape"},"skylith_512x512_crop":{"height":512,"width":512,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-512x512.jpg","orientation":"landscape"},"skylith_512x512":{"height":294,"width":512,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-512x294.jpg","orientation":"landscape"},"skylith_800x600_crop":{"height":600,"width":800,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-800x600.jpg","orientation":"landscape"},"skylith_800x600":{"height":459,"width":800,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-800x459.jpg","orientation":"landscape"},"skylith_1280x720_crop":{"height":641,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1280x720.jpg","orientation":"landscape"},"skylith_1280x720":{"height":654,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1280x734.jpg","orientation":"landscape"},"skylith_1920x1080_crop":{"height":641,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1920x1080.jpg","orientation":"landscape"},"skylith_1920x1080":{"height":654,"width":1140,"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts-1920x1101.jpg","orientation":"landscape"},"full":{"url":"https://wp.nkdev.info/skylith/demo-creative-business-one-page/wp-content/uploads/sites/18/2018/10/demo-creative-business-facts.jpg","height":1101,"width":1920,"orientation":"landscape"}},"parallax":"scroll","parallaxSpeed":0.8,"className":"ghostkit-custom-IOpF","ghostkitStyles":{".ghostkit-custom-IOpF":{"paddingTop":"100","paddingBottom":"270","paddingLeft":"0","paddingRight":"0"}},"ghostkitClassname":"ghostkit-custom-IOpF","ghostkitId":"IOpF","ghostkitSpacings":{"paddingTop":"100","paddingBottom":"270","paddingLeft":"0","paddingRight":"0"}} -->
<div class="wp-block-nk-awb nk-awb  alignfull ghostkit-custom-IOpF" id="about"><div class="nk-awb-wrap" data-awb-type="image" data-awb-image-background-size="cover" data-awb-image-background-position="50% 50%" data-awb-parallax="scroll" data-awb-parallax-speed="0.8" data-awb-parallax-mobile="false"><div class="nk-awb-inner"><img src="http://skylith.local/wp-content/uploads/2018/09/demo-minimal-split-single-4-3.png" class="wp-image-37 jarallax-img" width="1280" height="1610" /></div></div><!-- wp:heading {"align":"center","className":"h1 ghostkit-custom-nLq9s","ghostkitStyles":{".ghostkit-custom-nLq9s":{"marginBottom":"30"}},"ghostkitClassname":"ghostkit-custom-nLq9s","ghostkitId":"nLq9s","ghostkitSpacings":{"marginBottom":"30"},"ghostkitSR":"fade-up;distance:10px"} -->
<h2 class="has-text-align-center h1 ghostkit-custom-nLq9s" data-ghostkit-sr="fade-up;distance:10px">Some Facts About Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","customTextColor":"#0f1d56","ghostkitSR":"fade-up;distance:10px"} -->
<p style="color:#0f1d56" class="has-text-color has-text-align-center" data-ghostkit-sr="fade-up;distance:10px">Vivamus ut scelerisque tellus. Morbi egestas neque et lorem sodales faucibus. Etiam&nbsp;<br>efficitur vehicula commodo. Curabitur ac libero ullamcorper,&nbsp;<br>interdum arcu et, posuere arcu.</p>
<!-- /wp:paragraph -->

<!-- wp:ghostkit/grid {"columns":4,"className":"ghostkit-custom-ZHFXVw","ghostkitStyles":{".ghostkit-custom-ZHFXVw":{"marginTop":"90"}},"ghostkitClassname":"ghostkit-custom-ZHFXVw","ghostkitId":"ZHFXVw","ghostkitSpacings":{"marginTop":"90"}} -->
<div class="ghostkit-grid ghostkit-grid-gap-md ghostkit-custom-ZHFXVw"><div class="ghostkit-grid-inner"><!-- wp:ghostkit/grid-column {"md_size":"12","lg_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-md-12 ghostkit-col-lg-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-portfolio","iconSize":49.5,"iconColor":"#148ff3","className":"ghostkit-custom-ZVOmPN","ghostkitStyles":{".ghostkit-custom-ZVOmPN":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"49.5px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#148ff3"}},"ghostkitClassname":"ghostkit-custom-ZVOmPN","ghostkitId":"ZVOmPN","ghostkitSR":"fade-up;distance:10px"} -->
<div class="ghostkit-icon-box ghostkit-custom-ZVOmPN" data-ghostkit-sr="fade-up;distance:10px"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-portfolio"></span></div><div class="ghostkit-icon-box-content"><!-- wp:heading {"level":3,"className":"h2 text-dark ghostkit-custom-Zc1yxp","ghostkitStyles":{".ghostkit-custom-Zc1yxp":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}},"ghostkitClassname":"ghostkit-custom-Zc1yxp","ghostkitId":"Zc1yxp","ghostkitSpacings":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}} -->
<h3 class="h2 text-dark ghostkit-custom-Zc1yxp">548</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"className":"h6 ghostkit-custom-ZFUcOC","ghostkitStyles":{".ghostkit-custom-ZFUcOC":{"marginLeft":"7"}},"ghostkitClassname":"ghostkit-custom-ZFUcOC","ghostkitId":"ZFUcOC","ghostkitSpacings":{"marginLeft":"7"}} -->
<h3 class="h6 ghostkit-custom-ZFUcOC">Projects Completed</h3>
<!-- /wp:heading --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"md_size":"12","lg_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-md-12 ghostkit-col-lg-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-clock","iconSize":49.5,"iconColor":"#148ff3","className":"ghostkit-custom-ZbAPLE","ghostkitStyles":{".ghostkit-custom-ZbAPLE":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"49.5px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#148ff3"}},"ghostkitClassname":"ghostkit-custom-ZbAPLE","ghostkitId":"ZbAPLE","ghostkitSR":"fade-up;distance:10px;delay:100"} -->
<div class="ghostkit-icon-box ghostkit-custom-ZbAPLE" data-ghostkit-sr="fade-up;distance:10px;delay:100"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-clock"></span></div><div class="ghostkit-icon-box-content"><!-- wp:heading {"level":3,"className":"h2 text-dark ghostkit-custom-1upK4Q","ghostkitStyles":{".ghostkit-custom-1upK4Q":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}},"ghostkitClassname":"ghostkit-custom-1upK4Q","ghostkitId":"1upK4Q","ghostkitSpacings":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}} -->
<h3 class="h2 text-dark ghostkit-custom-1upK4Q">1465</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"className":"h6 ghostkit-custom-QGss5","ghostkitStyles":{".ghostkit-custom-QGss5":{"marginLeft":"7"}},"ghostkitClassname":"ghostkit-custom-QGss5","ghostkitId":"QGss5","ghostkitSpacings":{"marginLeft":"7"}} -->
<h3 class="h6 ghostkit-custom-QGss5">Working Hours</h3>
<!-- /wp:heading --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"md_size":"12","lg_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-md-12 ghostkit-col-lg-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-star","iconSize":49.5,"iconColor":"#148ff3","className":"ghostkit-custom-14cAU4","ghostkitStyles":{".ghostkit-custom-14cAU4":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"49.5px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#148ff3"}},"ghostkitClassname":"ghostkit-custom-14cAU4","ghostkitId":"14cAU4","ghostkitSR":"fade-up;distance:10px;delay:200"} -->
<div class="ghostkit-icon-box ghostkit-custom-14cAU4" data-ghostkit-sr="fade-up;distance:10px;delay:200"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-star"></span></div><div class="ghostkit-icon-box-content"><!-- wp:heading {"level":3,"className":"h2 text-dark ghostkit-custom-Z2J10P","ghostkitStyles":{".ghostkit-custom-Z2J10P":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}},"ghostkitClassname":"ghostkit-custom-Z2J10P","ghostkitId":"Z2J10P","ghostkitSpacings":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}} -->
<h3 class="h2 text-dark ghostkit-custom-Z2J10P">612</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"className":"h6 ghostkit-custom-Z2iTAN8","ghostkitStyles":{".ghostkit-custom-Z2iTAN8":{"marginLeft":"7"}},"ghostkitClassname":"ghostkit-custom-Z2iTAN8","ghostkitId":"Z2iTAN8","ghostkitSpacings":{"marginLeft":"7"}} -->
<h3 class="h6 ghostkit-custom-Z2iTAN8">Positive Feedbacks</h3>
<!-- /wp:heading --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column -->

<!-- wp:ghostkit/grid-column {"md_size":"12","lg_size":"6","size":"3"} -->
<div class="ghostkit-col ghostkit-col-md-12 ghostkit-col-lg-6 ghostkit-col-3"><div class="ghostkit-col-content"><!-- wp:ghostkit/icon-box {"icon":"pe-7s-like","iconSize":49.5,"iconColor":"#148ff3","className":"ghostkit-custom-13hkxI","ghostkitStyles":{".ghostkit-custom-13hkxI":{"\u002d\u002dgkt-icon-box\u002d\u002dicon__font-size":"49.5px","\u002d\u002dgkt-icon-box\u002d\u002dicon__color":"#148ff3"}},"ghostkitClassname":"ghostkit-custom-13hkxI","ghostkitId":"13hkxI","ghostkitSR":"fade-up;distance:10px;delay:300"} -->
<div class="ghostkit-icon-box ghostkit-custom-13hkxI" data-ghostkit-sr="fade-up;distance:10px;delay:300"><div class="ghostkit-icon-box-icon ghostkit-icon-box-icon-align-left"><span class="pe-7s-like"></span></div><div class="ghostkit-icon-box-content"><!-- wp:heading {"level":3,"className":"h2 text-dark ghostkit-custom-2eSFBP","ghostkitStyles":{".ghostkit-custom-2eSFBP":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}},"ghostkitClassname":"ghostkit-custom-2eSFBP","ghostkitId":"2eSFBP","ghostkitSpacings":{"marginTop":"7","marginLeft":"7","marginBottom":"10"}} -->
<h3 class="h2 text-dark ghostkit-custom-2eSFBP">735</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"className":"h6 ghostkit-custom-Z1nOKsn","ghostkitStyles":{".ghostkit-custom-Z1nOKsn":{"marginLeft":"7"}},"ghostkitClassname":"ghostkit-custom-Z1nOKsn","ghostkitId":"Z1nOKsn","ghostkitSpacings":{"marginLeft":"7"}} -->
<h3 class="h6 ghostkit-custom-Z1nOKsn">Happy Clients</h3>
<!-- /wp:heading --></div></div>
<!-- /wp:ghostkit/icon-box --></div></div>
<!-- /wp:ghostkit/grid-column --></div></div>
<!-- /wp:ghostkit/grid --></div>
<!-- /wp:nk/awb -->
