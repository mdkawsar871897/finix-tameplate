<?php
/**
 * Posts archive template file.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package skylith
 */

get_template_part( 'index' );
