<?php
/**
 * Search icon.
 *
 * @package @@plugin_name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

<span class="pe-7s-look"></span>
