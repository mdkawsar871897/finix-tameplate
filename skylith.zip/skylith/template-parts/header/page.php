<?php
/**
 * Search Header
 *
 * @package skylith
 */

skylith_print_header( 'single_page' );
