<?php
/**
 * Portfolio Header
 *
 * @package skylith
 */

skylith_print_header( 'portfolio' );
