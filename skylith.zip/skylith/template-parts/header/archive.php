<?php
/**
 * Archive Header
 *
 * @package skylith
 */

skylith_print_header( 'archive' );
