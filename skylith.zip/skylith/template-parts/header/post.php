<?php
/**
 * Posts Header
 *
 * @package skylith
 */

skylith_print_header( 'single_post' );
