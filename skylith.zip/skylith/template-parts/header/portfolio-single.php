<?php
/**
 * Portfolio Single Header
 *
 * @package skylith
 */

skylith_print_header( 'single_portfolio' );
