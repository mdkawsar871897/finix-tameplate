<?php
/**
 * WordPress shims.
 *
 * @package skylith
 */

if ( ! function_exists( 'wp_body_open' ) ) {
    /**
     * Adds backwards compatibility for wp_body_open() introduced with WordPress 5.2
     *
     * @see https://developer.wordpress.org/reference/functions/wp_body_open/
     */
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}
